# The Nexus Story Catalog

## Fantasy
- fantasy_spirit_keeper.json - 30 nodes - 8 endings
## Past
- past_viking_voyage.json - 22 nodes - 7 endings
- past_rome_scribe.json - 20 nodes - 7 endings
## Future
- future_digital_silence.json - 22 nodes - 6 endings
## Alternate
- alternate_cracked_time.json - 20 nodes - 8 endings
